# This is a basic workflow that is manually triggered

name: Running Docker && image

# Controls when the action will run. Workflow runs when manually triggered using the UI
# or API.
on:
  workflow_dispatch:
    # Inputs the workflow accepts.
    inputs:
      name:
        # Friendly description to be shown in the UI instead of 'name'
        description: 'Smoke test'
        # Default value if no value is explicitly provided
        default: 'Smoke test - jest - puppeteer'
        # Input has to be provided for the workflow to run
        required: true

# A workflow run is made up of one or more jobs that can run sequentially or in parallel
jobs:
  # This workflow contains a single job called "greet"
  buildDocker:
    name: "Building docker image"
    runs-on: ubuntu-18.04
    steps:
      - name: Code checkout
        uses: actions/checkout@v1
      - name: List project files
        run: |
          ls -ltr && pwd   
      - name: Pulling docker image
        uses: docker pull dkiro/-     
      - name: Run docker and installing node_modules
        run: yarn install
      - name: Run tests
        run: ls && SETTINGS='tca' yarn run test:smokeCSR