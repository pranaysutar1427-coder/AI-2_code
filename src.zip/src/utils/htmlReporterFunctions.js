const { addAttach } = require("jest-html-reporters/helper");

async function attachScreenshot(page, screenshotName) {

  const data = await page.screenshot();
  await addAttach({
    attach: data,
    description: screenshotName,
  });

}

module.exports = { 
  attachScreenshot

}
