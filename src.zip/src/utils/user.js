class User {
  static fromString(str) {
    if (str.indexOf(':') < 0) {
      throw new TypeError(
        `User string must be username:password. Got "${str}"`
      );
    }

    const [username, password] = str.split(/:(.+)/);

    return new User(username, password);
  }

  constructor(username, password) {
    this.username = username;
    this.password = password;
  }
}

module.exports = User;
