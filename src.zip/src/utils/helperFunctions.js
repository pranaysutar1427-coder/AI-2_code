async function verifyTextXpath(page, xpathElement, expectedText) {

  const elementXpath = await page.$x(xpathElement);
  var getTextJSon = await elementXpath[0].getProperty('textContent');
  var actualText = await getTextJSon.jsonValue();
  await expect(actualText).toEqual(expectedText);

}

async function clearText(page, selector) {
  const input = await page.$(selector)
  await input.click({ clickCount: 3 })
  await page.keyboard.press('Backspace')
}

module.exports = { 
  verifyTextXpath,
  clearText,
}
