async function chooseReactSelect(page, reactSelectSelector, optionText) {
  const e = await page.$(`${reactSelectSelector} .Select-placeholder`);
  const box = await e.boundingBox();

  await page.mouse.move(~~(box.x + box.width / 2), ~~(box.y + box.height / 2));
  await page.mouse.down();

  await page.evaluate(
    (reactSelectSelector, optionText) => {
      const options = Array.from(
        document.querySelectorAll(`${reactSelectSelector} .Select-option`)
      ).filter(element => element.textContent === optionText);

      if (options.length > 0) {
        options[0].click();
      } else {
        throw Error('Option not found', optionText);
      }
    },
    reactSelectSelector,
    optionText
  );
}

//export default chooseReactSelect;
module.exports = chooseReactSelect;
