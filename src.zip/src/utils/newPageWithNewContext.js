async function newPageWithNewContext(browser) {
  const { browserContextId } = await browser._connection.send(
    'Target.createBrowserContext'
  );
  const page = await browser._createPageInContext(browserContextId);
  page.browserContextId = browserContextId;
  page.setDefaultTimeout(30000);
  return page;
}

module.exports = newPageWithNewContext;
