var config = require('../config');

const delay = milliseconds => {
    return new Promise(resolve => setTimeout(resolve, milliseconds));
  };


async function clickOnForgotPassword(page){
    const forgotPasswordLink = await page.$x("//a[contains(@href,'forgot-password')]");
    await forgotPasswordLink[0].click();

}

async function enterUsernameAndClickSubmitForgotPassword(page, username){
  await page.type('input[name="username"]', username);
  await page.click('button[type="submit"]');

}

async function clickBackToLogin(page){
  const backToLoginLink = await page.$x("//a[contains(@href,'login')]");
  await backToLoginLink[0].click();

}

async function clickOnClientName(page){

  await page.waitForXPath("//a[@class='css-11w9905 e18wxu1p5']", { timeout: config.timeout }, { visible: true });
  const clientName = await page.$x("//a[@class='css-11w9905 e18wxu1p5']");
  await clientName[0].click();
  await page.waitForXPath("//div[@class='ui header'][text()='Change Enterprise']", { timeout: config.timeout }, { visible: true });

}

async function clickOnCloseChangeEnterprise(page){
    
  const closeButton = await page.$x("//button[text()=' Close']");
  await closeButton[0].click();

}

async function loginToCSR(page, username, password){
  
  await expect(page).toMatch('Forgot');
  await page.type('input[name="username"]', username);
  await page.type('input[name="password"]', password);
  await page.click('button');
  await page.waitForXPath("//div[@role='alert'][text()='Unavailable']", { timeout: config.timeout }, { visible: true });
  await page.waitForXPath("//img[@alt='AMN Healthcare Logo']", { timeout: config.timeout }, { visible: true });

}

async function csrChangeUserStatus(page, status){
    
    await delay(1000);
    await page.waitForXPath("(//div[@role='listbox'])[2]", { visible: true });
    const availabilityMenuButton = await page.$x("(//div[@role='listbox'])[2]");
    await availabilityMenuButton[0].click();
    await page.waitForXPath("//span[@class='text'][text()='"+status+"']", { timeout: config.timeout }, { visible: true });
    const toSetStatus = await page.$x("//span[@class='text'][text()='"+status+"']");
    await toSetStatus[0].click();
    await page.waitForXPath("//div[@role='alert'][text()='"+status+"']", { visible: true });

}

async function csrLogout(page){
    
  await page.waitForXPath("(//div[@role='listbox'])[1]", { visible: true });
  const userMenuButton = await page.$x("(//div[@role='listbox'])[1]");
  await userMenuButton[0].click();
  await page.waitForXPath("//i[@class='sign out icon']", { timeout: config.timeout }, { visible: true });
  const logoutButton = await page.$x("//i[@class='sign out icon']");
  await logoutButton[0].click();
  await page.waitForXPath("//h1[text()='Logged Out']", { visible: true });

  await delay(2000);

}


async function csrDeclineCall(page){
    
  await page.waitForXPath("//div[@class='ui tiny modal transition visible active']", { timeout: config.timeout }, { visible: true });
  const callDeclineButton = await page.$x("//button[text()='Decline']");
  await callDeclineButton[0].click();
  await page.waitForXPath("//div[@role='alert'][text()='Unavailable']", { timeout: config.timeout }, { visible: true });

}

async function csrAcceptCall(page){

  await page.waitForXPath("//div[@class='ui tiny modal transition visible active']", { timeout: config.timeout }, { visible: true });
  const callAcceptButton = await page.$x("//button[text()='Accept']");
  await callAcceptButton[0].click();
  await page.waitForXPath("//div[@role='alert'][text()='In-Call']", { timeout: config.timeout }, { visible: true });

}

async function closeNotification(page){
    
  await page.waitForXPath("//button[@class='css-1i2txrk']//i[@class='remove icon']", { timeout: config.timeout }, { visible: true });
  const closeNotificationButton = await page.$x("//button[@class='css-1i2txrk']//i[@class='remove icon']");
  await closeNotificationButton[0].click();

}

async function csrEndCall(page){
  
  await page.waitForXPath("//button[text()='Leave']", { timeout: config.timeout }, { visible: true });
  const endButton = await page.$x("//button[text()='Leave']");
  await endButton[0].click();

  await page.waitForXPath("//button[text()='OK']", { timeout: config.timeout }, { visible: true });
  const okButton = await page.$x("//button[text()='OK']");
  await okButton[0].click();
  
  await delay(3000);

  await page.waitForXPath("//h2[text()='Session Complete']", { timeout: config.timeout }, { visible: true });
  await expect(page).toMatchElement('h2', {text: 'Session Complete'}, {timeout: config.timeout}, { visible: true });

  await page.waitForXPath("//h5[text()='AVAILABILITY']", { timeout: config.timeout }, { visible: true });

}

module.exports = {
  clickOnForgotPassword,
  enterUsernameAndClickSubmitForgotPassword,
  clickBackToLogin,
  clickOnClientName,
  clickOnCloseChangeEnterprise,
  loginToCSR,
  csrChangeUserStatus,
  csrLogout,
  csrDeclineCall,
  csrAcceptCall,
  closeNotification,
  csrEndCall,
  
 }