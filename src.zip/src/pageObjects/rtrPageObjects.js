var config = require('../config');


const usernameField = 'input[name="username'; //selector
const passwordField = 'input[name="password"]'; //selector
const continueButton = "//button[@type='submit']";
const signInButton = 'button'; //selector
const usernameText = '.Header__menu-right___1PitE'; //selector
const workforceTab = 'a[href="/report/workforce"]';
const pointToPointTab = 'a[href="/report/ptop"]';
const acdTab = 'a[href="/report/acd"]';
const queueRequestsTab = 'a[href="/report/queue-requests"]';
const alertsTab = 'a[href="/report/alerts"]';
const workforceTableHeader = '.Interpreters__main___1Idrq';
const pointToPointTableHeader = '.Ptop__main___3ZAwa';
const acdTableHeader = '.ACD__main___2MUsJ';
const queueRequestsTableHeader = '.QueueRequests__main___nu1t5';
const alertsTableHeader = '.List__main___3ydUH';


async function loginToRTR(page, username, password){
  await page.waitForSelector(usernameField, { timeout: config.timeout }, { visible: true });
  await page.type(usernameField, username);
  const continueButtonObj = await page.$x(continueButton);
  await continueButtonObj[0].click();
  await page.waitFor(2000);
  await page.waitForSelector(passwordField, { timeout: config.timeout }, { visible: true });
  await page.type(passwordField, password);
  await page.click(signInButton);
  await page.waitForSelector(usernameText, { timeout: config.timeout }, { visible: true });
  await page.waitFor(1000);
}

async function logoutFromRTR(page){
  
}

async function navigateToWorkforce(page){

  await page.waitForSelector(workforceTab, { timeout: config.timeout }, { visible: true });
  await page.click(workforceTab);
  await page.waitForSelector(workforceTableHeader, { timeout: config.timeout }, { visible: true });
  
}

async function navigateToPointToPoint(page){

  await page.waitForSelector(pointToPointTab, { timeout: config.timeout }, { visible: true });
  await page.click(pointToPointTab);
  await page.waitForSelector(pointToPointTableHeader, { timeout: config.timeout }, { visible: true });
  
}

async function navigateToACD(page){

  await page.waitForSelector(acdTab, { timeout: config.timeout }, { visible: true });
  await page.click(acdTab);
  await page.waitForSelector(acdTableHeader, { timeout: config.timeout }, { visible: true });
  
}

async function navigateToQueueRequests(page){

  await page.waitForSelector(queueRequestsTab, { timeout: config.timeout }, { visible: true });
  await page.click(queueRequestsTab);
  await page.waitForSelector(queueRequestsTableHeader, { timeout: config.timeout }, { visible: true });
  
}

async function navigateToAlerts(page){

  await page.waitForSelector(alertsTab, { timeout: config.timeout }, { visible: true });
  await page.click(alertsTab);
  await page.waitForSelector(alertsTableHeader, { timeout: config.timeout }, { visible: true });
  
}

async function getUserStatus(page, username){

  await page.waitForXPath("//a[text()='"+username+"']//preceding::button[1]", { timeout: config.timeout }, { visible: true });
  const statusObj = await page.$x("//a[text()='"+username+"']//preceding::button[1]");
  var getTextJSonStart = await statusObj[0].getProperty('textContent');
  var currentStatus = await getTextJSonStart.jsonValue();

  return currentStatus;
  
}

async function getQueueRequestsStatus(page, username){

  await page.waitForXPath("//div[text()='"+username+"']//preceding::div[1]", { timeout: config.timeout }, { visible: true });
  const statusObj = await page.$x("//div[text()='"+username+"']//preceding::div[1]");
  var getTextJSonStart = await statusObj[0].getProperty('textContent');
  var currentStatus = await getTextJSonStart.jsonValue();

  return currentStatus;
  
}


module.exports = { 
    loginToRTR,
    logoutFromRTR,
    navigateToWorkforce,
    navigateToPointToPoint,
    navigateToACD,
    navigateToQueueRequests,
    navigateToAlerts,
    getUserStatus,
    getQueueRequestsStatus,
    
 }