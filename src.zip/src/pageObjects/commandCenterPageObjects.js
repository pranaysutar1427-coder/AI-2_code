var config = require('../config');

const usernameField = 'input[name="username"]';
const passwordField = 'input[name=password]';
const continueButton = '//button[@type="submit"]';
const ssoContinueButton = 'button[type="submit"]';
const button = 'button';
const networkIdle = 'networkidle2';
const invalidLoginMesaage = '//*[text()="Username or password is incorrect.  Try again."]';
const skipToDashboardButton = '//*[text()="Go to languages"]';
const cancelButton = '//button[@type="button"]';
const callEndButton = ".controls-end";
const settingsToggle = ".settingsToggle";
const videoContainer = "#remoteVideo";
const holidayExpandCollapseButton = 'button[aria-controls="holiday-schedule-id-0"]';
const startStopBtn = '//*[text()="Speed test"]';
//const audioIVVR = '#ivvrVideo';


async function login(page, username, password) {

  await page.waitForSelector(usernameField);
  await page.type(usernameField, username);
  const continueButtonObj = await page.$x(continueButton);
  await continueButtonObj[0].click();
  await page.waitFor(2000);
  await page.waitForSelector(passwordField);
  await page.type(passwordField, password);
  await Promise.all([
    page.click(button),
    //page.waitForNavigation({ waitUntil: 'networkidle0' }),
  ]);
}

async function ssoLogin(page, username, password) {
  await page.waitForSelector(usernameField);
  await page.type(usernameField, username);
  await clickContinueButton(page);
  await page.waitFor(3000);
  await page.waitForSelector(usernameField);
  await page.type(usernameField, username);
  await clickContinueButton(page);
  await page.waitFor(2000);
  await page.waitForSelector(passwordField);
  await page.type(passwordField, password);
  await page.waitFor(2000);
  await clickOneLoginContinueButton(page);
  await page.waitFor(20000);
}

async function badLogin(page, username) {
  await page.waitForSelector(usernameField, { timeout: config.timeout }, { visible: true });
  await page.type(usernameField, username);

  try {
    await page.waitForSelector(passwordField, { timeout: 1000 }, { visible: true });
    await page.type(passwordField, password);
  } catch (error) {
    const continueButtonObj = await page.$x(continueButton);
    await continueButtonObj[0].click();
    await page.waitForSelector(passwordField, { timeout: config.timeout }, { visible: true });
    await page.type(passwordField, "BadPassword");

  }
  await page.click(button);
}

async function clickContinueButton(page) {
  await page.waitForXPath(continueButton, { timeout: config.timeout }, { visible: true });
  const continueButtonObj = await page.$x(continueButton);
  await continueButtonObj[0].click();;
}

async function clickOneLoginContinueButton(page) {
  await page.waitForSelector(ssoContinueButton, { timeout: config.timeout }, { visible: true });
  await Promise.all([
    page.click(ssoContinueButton),
    page.waitForNavigation({ waitUntil: 'networkidle0' }),
  ]);
}

async function logout(page) {
  const logoutbtnn = await page.$x('//button[@type="button"]');
  await logoutbtnn[1].click();
  await page.waitFor(3000);
  const sigoutbtn = await page.$x('//*[text()="Sign out"]');
  await sigoutbtn[0].click();
  await page.waitFor(5000);
}

//span[@claas='sr-only']/'Settings and more for'

async function clickSkipToDashboard(page) {
  //await page.waitForXPath(skipToDashboardButton, { timeout: config.timeout }, { visible: true });
  const elementsSkipToDashboard = await page.$x('//*[text()="Go to languages"]');
  await elementsSkipToDashboard[0].click();
  await expect(page).toMatchElement('button', { text: 'Other Languages (Audio)' }, { timeout: config.timeout }, { visible: true });
}

async function clickCancelButton(page) {
  //await page.waitForXPath(cancelButton, { timeout: config.timeout }, { visible: true });
  const elementsCancelButton = await page.$x('//*[text()="Cancel request"]');
  await elementsCancelButton[0].click();
  await expect(page).toMatchElement('button', { text: 'Cancel request' }, { timeout: config.timeout }, { visible: true });
}

async function navigateToLanguages(page) {
  const elementsS = await page.$x('//*[text()="Languages"]');
  await elementsS[0].click();
  await page.waitFor(2000);
  await expect(page).toMatchElement('button', { text: 'Other Languages (Audio)' }, { timeout: config.timeout }, { visible: true });
  await page.waitFor(4000);
}

async function navigateToSessionHistory(page) {

  const sessionhistory = await page.$x('//*[text()="Session History"]');
  await sessionhistory[0].click();
  await page.waitFor(2000);
  const selectday = await page.$x('//*[text()="All"]');
  await selectday[0].click();
  await page.waitFor(2000);
  const clcikonday = await page.$x('//div[@tabindex="-1"]');
  await clcikonday[1].click();
  await page.waitFor(2000);
  const selectlang = await page.$x('//*[text()="All"]');
  await selectlang[1].click();
  await page.waitFor(2000);
  const clicklang = await page.$x('//*[@data-key="Spanish"]');
  await clicklang[0].click();
  await page.waitFor(2000);
}

async function navigateToSessionHistoryStartTime(page) {

  const sessionhistory = await page.$x('//*[text()="Session History"]');
  await sessionhistory[0].click();
  await page.waitFor(2000);
  const selectday = await page.$x('//*[text()="All"]');
  await selectday[0].click();
  await page.waitFor(2000);
  const clcikonday = await page.$x('//div[@tabindex="-1"]');
  await clcikonday[1].click();
  await page.waitFor(2000);
  const selectlang = await page.$x('//*[text()="All"]');
  await selectlang[1].click();
  await page.waitFor(2000);
  const clicklang = await page.$x('//*[@data-key="Spanish"]');
  await clicklang[0].click();
  await page.waitFor(2000);
  const time = await page.$x('//td[@tabindex="-1"]');
  await time[0].click();
  await page.waitFor(2000);
}

async function navigateToSupport(page) {
  const elementsSupport = await page.$x('//a[text()="Support"]');
  await elementsSupport[0].click();
  await page.waitFor(3000);
}

async function appversion(page) {
  const appversion = await page.$x("//*[contains(text(), 'v1.25.8')]");
  await page.waitFor(3000);
}

async function navigateToSettings(page) {
  const elementsSupport = await page.$x("//a[text()='Settings']");
  await elementsSupport[0].click();
  await page.waitFor(2000);
  const hdcall = await page.$x('//*[text()="HD (1280x720) [default]"]');
  await hdcall[0].click();
  await hdcall[0].click();
  await page.waitFor(4000);
}


async function navigateToTraningVideo(page) {
  const elementsTrainingVid = await page.$x('//*[text()="Training Videos"]');
  await elementsTrainingVid[0].click()
}

async function navigateToMediaDiagnosticsAndRunTest(page) {
  const elementsMediaDiag = await page.$x('//*[text()="Media Diagnostics"]');
  await elementsMediaDiag[0].click();
  await expect(page).toMatchElement('h2', { text: 'Media Diagnostics' });
  const elementsYes1 = await page.$x('//*[text()="Yes"]');
  await elementsYes1[0].click();
  await page.waitFor(2000);
  const elementsYes2 = await page.$x('//*[text()="Yes"]');
  await elementsYes2[0].click();
}

async function restartChecks(page) {
  const restartChecks = await page.$x('//*[text()="Restart checks"]');
  await restartChecks[0].click();
}

async function ClientRefresh(page) {
  const refreshcallbtn = await page.$x('//button[@aria-label="Refresh Call"]');
  await refreshcallbtn[0].click();
  await page.waitFor(10000);

}

async function RefreshCall(page) {
  const refreshcallbtn = await page.$x('//button[@aria-label="Refresh Call"]');
  await refreshcallbtn[0].click();
  await page.waitFor(10000);
  const continuelang = await page.$x('//*[text()="Continue to languages"]');
  await continuelang[0].click();
  await page.waitFor(10000);
  const endbtn = await page.$x('//button[text()="End Session"]');
  await page.waitFor(2000);
  await endbtn[0].click();
  await page.waitFor(10000);
}

async function ssologout(page) {
  
  const ssologout = await page.$x('//button[@type="button"]');
  await ssologout[0].click();
  await page.waitFor(5000);
  const sigoutbtn = await page.$x('//*[text()="Sign out"]');
  await sigoutbtn[0].click();
  await page.waitFor(5000);
}



async function navigateToLanguageHours(page) {
  const elementsLangHours = await page.$x('//*[text()="Language Hours"]');
  await elementsLangHours[0].click();
}

async function clickHolidaySchedule(page) {
  const elementsLangchedule = await page.$x("(//button[@class='holiday-accordion--button'])[1]");
  await elementsLangchedule[1].click();
}

async function navigateToContactPage(page) {
  const elementsContact = await page.$x('//*[text()="Contact"]');
  await elementsContact[0].click();
  await page.waitFor(3000);
}

async function contactSupport(page) {
  const contactSupport = await page.$x('//*[text()="Connect with support"]');
  await contactSupport[0].click();
  await page.waitFor(10000);
}

async function navigateToRing(page) {
  const elementsContact = await page.$x("//li[text()='Ring']");
  await elementsContact[0].click();
}

async function runRingTest(page) {
  const elementsTestRingSetting = await page.$x("//button[text()='Test Ring Settings']");
  await elementsTestRingSetting[0].click();
  await page.waitFor(3000);
  const elementsStopRing = await page.$x("//button[text()='Stop']");
  await elementsStopRing[0].click();
}

async function navigateToSpeedTest(page) {
  const speedTest = await page.$x('//*[text()="Speed test"]');
  await speedTest[0].click();
  await page.waitFor(2000);
}

async function startBtn(page) {
  const startBtn = await page.$x('//*[@id="startStopBtn"]');
  await startBtn.click();

}

async function clickSpeedTestButton(page) {
  const SpeedTestButton = await page.$x(startStopBtn);
  await SpeedTestButton[0].click();
  await page.waitFor(3000);
  const Startbutt = await page.$x(startStopBtn);
  await Startbutt[0].click();
}

async function abortBtn(page) {
  const abortBtn = await page.$x('//*[text()="Abort"]');
  await abortBtn.click();

}

async function callCST(page) {
  const elementsLangHours = await page.$x("//button[text()='Connect with Support']");
  await elementsLangHours[0].click();
}

async function endCSTAndNavigateToDashboard(page) {
  const elementsLangHours = await page.$x("//button[text()='Connect with Support']");
  await elementsLangHours[0].click();
}

async function initiateAudioCall(page) {
  const elementsAudioLanguageButton = await page.$x("//button[text()='Other Languages (Audio)']");
  await elementsAudioLanguageButton[0].click();
  //await page.waitForSelector(audioIVVR, { timeout: config.timeout }, { visible: true });
}

async function endAudioCall(page) {
  await page.waitForSelector(callEndButton, { timeout: config.timeout }, { visible: true });
  await page.click(callEndButton);
}

async function lonotificaation(page) {

  const notification = await page.$x('//*[@aria-label="Notification center"]');
  await notification[0].click();
  await page.waitFor(3000);
  const DeviceTargetNotification = await page.$x('//*[text()="Device Target Notification"]');
  await page.waitFor(3000);
  const closebtn = await page.$x('//button[@type="button"]');
  await closebtn[0].click();
  await page.waitFor(3000);
}

async function feedbackque(page) {
  
  const boolean = await page.$x('//button[@type="button"]');
  await boolean[2].click();
  await page.waitFor(2000);
  const booleanans = await page.$x('//div[@tabindex="-1"]');
  await booleanans[2].click();
  await page.waitFor(3000);
  const selectdate = await page.$x('//input[@type="date"]');
  await selectdate[0].click();
  await page.waitFor(3000);
}

async function submitFeedback(page) {
  //await page.waitForSelector('div[class="rating-container rating-fa"]', { timeout: config.timeout }, { visible: true });
  //await page.click('div[class="rating-cfer rating-fa"]');
  const elementsSubmitButton = await page.$x("//button[text()='Submit feedback']");
  await elementsSubmitButton[0].click();
  await page.waitFor(10000);
}

async function checkifFreeAndCancelResumeDialog(page) {
  const isFree = await page.evaluate(async () => {
    const response = await fetch('/api/me/session/current');
    return response.status === 204;
  });

  if (isFree) {
    return expect(isFree).toBe(true);
  }

  await page.waitForSelector('#resumeSessionModal', { visible: true });
  await page.click('#resumeSessionModal a[data-e2e="cancel"');
  await page.waitForNavigation({ waitUntil: 'networkidle2' });

  await expect(page).toMatch('Provide Feedback', { timeout: config.timeout });
  await expect(page).toClick('button', { text: 'Skip' });
};


async function ssobanner(page) {
  await page.waitFor(10000);
  await page.reload();
  await page.waitFor(5000);
  const continuebtn = await page.$x('//button[text()="Continue"]');
  await page.waitFor(2000);
  const endbtn = await page.$x('//button[text()="End Session"]');
  await page.waitFor(2000);
  await continuebtn[0].click();
  await page.waitFor(15000);
}

async function verifyHolidayScheduleExpandCollapse(page) {
  await page.waitForSelector(holidayExpandCollapseButton, { timeout: config.timeout }, { visible: true });
  const buttonValue = await page.$eval(holidayExpandCollapseButton, el => el.getAttribute("aria-expanded"));
  return buttonValue;

}

async function addlanguaage(page) {

  const addlanguaage = await page.$x('//*[@id="filter-languages-input"]');
  await addlanguaage[0].click();
  await page.waitFor(3000);
  await addlanguaage[0].type('Spanish');
  await page.waitFor(3000);
  await addlanguaage[0].type(' ');
  await page.waitFor(3000);
  const nomatch = await page.$x('//*[text()="No languages matched."]');
  await page.waitFor(3000);
}

async function deviceid(page) {

  const deviceid = await page.$x('//*[@id="sven-app"]/div/div/div/div[2]/footer/div/div[1]/span');
  await deviceid[0].click();
}

async function accselection(page) {

    await page.waitFor('//div[@tabindex="0"]');
    await page.waitFor('//div[@tabindex="-1"]');
    await page.waitFor(3000);
    const createaccount = await page.$x('//div[@tabindex="-1"]');
    await createaccount[0].click();
    await page.waitFor(3000);  
    const level1 = await page.$x('//button[@type="button"]');
    await level1[1].click();
    await page.waitFor(2000);
    const selectLevel1 = await page.$x('//div[@tabindex="0"]');
    await selectLevel1[1].click();
    await page.waitFor(1000);
    await page.waitFor('//*[text()="Location Level 2 selection required"]')
}

async function accselection2(page) {

    const level2 = await page.$x('//button[@type="button"]');
    await level2[2].click();
    await page.waitFor(2000);
    const selectLevel2 = await page.$x('//div[@tabindex="0"]');
    await selectLevel2[1].click();
    await page.waitFor(2000);
    const addShrotcut = await page.$x('//button[@type="submit"]');
    await addShrotcut[0].click();
}

async function deleteacc(page) {
  
    await page.waitFor('//div[@class="text-sm text-black/70 break-anywhere"]');
    await page.waitFor('//div[@class="font-semibold break-anywhere"]');
    await delay(2000);
    const selectedaccbtn = page.$x('//div[@class="flex items-center space-x-2"]');
    await selectedaccbtn[0].click();
    await page.waitFor(5000);

    await expect(page).toMatchElement('a', { text: 'Languages' });
    await page.waitFor(2000);
    const accountbtn = await page.$x('//button[text()="NishantLavel2A"]');
    await accountbtn[0].click();
    await page.waitFor(3000);
    const checkbox = await page.$x('//input[@type="checkbox"]');
    await checkbox[0].click();
    await page.waitFor(3000);
    const deletbtn = await page.$x('//button[@type="button"]');
    await deletbtn[1].click();
    await page.waitFor(4000);
    await page.waitFor('//div[@tabindex="0"]');
    await page.waitFor('//div[@tabindex="-1"]');
}

async function acclogout(page) {
  
  const acclogout = await page.$x('//button[@type="button"]');
    await acclogout[0].click();
    await page.waitFor(3000);
    const sigoutbtn = await page.$x('//*[text()="Sign out"]');
    await sigoutbtn[0].click();
}


module.exports = {
  login,
  ssoLogin,
  badLogin,
  checkifFreeAndCancelResumeDialog,
  logout,
  addlanguaage,
  accselection,
  acclogout,
  deviceid,
  deleteacc,
  clickSkipToDashboard,
  clickCancelButton,
  contactSupport,
  accselection2,
  navigateToLanguages,
  lonotificaation,
  restartChecks,
  ClientRefresh,
  navigateToSupport,
  navigateToSettings,
  navigateToSessionHistoryStartTime,
  navigateToTraningVideo,
  RefreshCall,
  navigateToMediaDiagnosticsAndRunTest,
  navigateToLanguageHours,
  clickHolidaySchedule,
  appversion,
  navigateToContactPage,
  navigateToRing,
  runRingTest,
  initiateAudioCall,
  ssologout,
  startBtn,
  feedbackque,
  ssobanner,
  abortBtn,
  endAudioCall,
  clickSpeedTestButton,
  submitFeedback,
  verifyHolidayScheduleExpandCollapse,
  navigateToSpeedTest,
  navigateToSessionHistory,
  invalidLoginMesaage,
  videoContainer,
  //audioIVVR,
  skipToDashboardButton,

}