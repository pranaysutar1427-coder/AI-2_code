var config = require('../config');
var helperFuncs = require('../utils/helperFunctions');

const delay = milliseconds => {
    return new Promise(resolve => setTimeout(resolve, milliseconds));
  };

const usernameField = 'input[name="username"]';
const passwordField = 'input[name=password]';
const submitButton = 'button[type="submit"]';
const invalidLoginMesaage = "//form//li[1]";
const forgotPassword = "//a[contains(@href,'forgot-password')]";
const backToLogin = "//a[text()='Back to Login']";
const broadCastButton = 'a[aria-label="Agent Broadcast"]';
const composeButton = "//a[text()='Compose']";
const historyButton = "//a[text()='History']";
const templatesButton = "//a[text()='Templates']";
const saveButton = "//span[text()='Save']";
const addTemplateButton = "//span[text()='Add Template']";
const closeButton = "//span[text()='Close']";
const xCloseButton = 'button[aria-label="close"]';
const templateNameField = 'input[name="name"]';
const templateTitleField = 'input[name="title"]';
const templateMessageTypeField = "//label[text()='Message Type']//following::div[contains(text(),'Select')]//following::input[1]";
const templateMessageField = 'textarea[name="message"]';
const refreshButtonOnTemplate = "(//span[@class='bp3-button-text'])[1]";
const timeDisplayedOnTemplate = "(//span[@class='bp3-button-text'])[1]//preceding::span[1]";
const deleteBroadcastButton = 'button[class="bp3-button bp3-intent-danger"]';
const confirmButton = 'button[data-e2e="confirm-dialog-accept"]';
const templateNameDropdown = "//div[contains(text(),'Select')]//following::input[1]";
const notesField = 'input[name="notes"]';
const nextButton = "//span[text()='Next']";
const previousButton = "//span[text()='Previous']";
const backButton = "//span[text()='Back']";
const cancelButton = "//span[text()='Cancel']";
const sendButton = "//span[text()='Send']";
const targetUsersHeader = "//h3[text()='Target a Set of Users']";
const finalBroadcastReviewHeader = "//h3[text()='Final Broadcast Review']";
const viewFullBroadcastButton = "//span[text()='View Full Broadcast']";
const clearButtonMessageType = "//label[text()='Message Type']//following::div[7]";
const statusDefaultValueCompose = "//label[text()='Status']//following::div[4]";
const teamDefaultValueCompose = "//label[text()='Team']//following::div[4]";
const languagesDefaultValueCompose = "//label[text()='Languages']//following::div[4]";
const skillsDefaultValueCompose = "//label[text()='Skills']//following::div[4]";
const typeDefaultValueCompose = "//label[text()='Type']//following::div[5]";
const statusDropdownCompose = "//label[text()='Status']//following::input[1]";
const languagesDropdownCompose = "//label[text()='Languages']//following::input[1]";
const skillsDropdownCompose = "//label[text()='Skills']//following::input[1]";
const clearFilterButton = "//span[text()='Clear Filters']";
const userProfileButton = 'button[aria-label="Account"]';
const signOutButton = 'button[data-e2e="user-menu-item-logout"]';
const loginButton = "//span[text()='Login']";
const firstRecordInHistory = "//tbody[@role='rowgroup']//tr[@role='row'][1]//a";
const headerDialogBroadcastDetails = "#BroadcastItem--header";
const generalButton = "//button[text()='General']";
const targetButton = "//button[text()='Target']";
const finalUsersButton = "//button[text()='Final Users']";
const searchUsernameField = "#BroadcastHistoryView--ShowMessage--username";
const sortByDateButton = "//div[text()='Date']//parent::th";
const sortByTitleButton = "//div[text()='Title']//parent::th";
const sortByStatusButton = "//div[text()='Status']//parent::th";
const sortByNotesButton = "//div[text()='Notes']//parent::th";
const hideFilterTabButton = "//button[@class='bp3-button bp3-active bp3-minimal bp3-small css-15qe7ui']";
const unhideFilterTabButton = "//button[@class='bp3-button bp3-minimal bp3-small css-15qe7ui']";
const applyFilterButton = "//span[text()='Apply']";
const resetFilterButton = "//span[text()='Reset']";
const statusDropdownFilter = "//label[text()='Status']//following::input[1]";
const languagesDropdownFilter = "//label[text()='Languages']//following::input[1]";
const composeTabPanel = "//div[text()='Compose']";


async function badLogin(page, username) {
  await page.waitForSelector(usernameField, { timeout: config.timeout }, { visible: true });
  await page.type(usernameField, username);
  await page.type(passwordField, 'BadPassword');
  await page.click(submitButton);
}

async function clickOnForgotPassword(page){
  await page.waitForSelector(usernameField, { timeout: config.timeout }, { visible: true });
  const forgotPasswordLink = await page.$x(forgotPassword);
  await forgotPasswordLink[0].click();

}

async function enterUsernameAndClickSubmitForgotPassword(page, username){
  await page.type(usernameField, username);
  await page.click(submitButton);

}

async function clickBackToLogin(page){
  const backToLoginLink = await page.$x(backToLogin);
  await backToLoginLink[0].click();

}

async function clickLogin(page){
  await page.waitForXPath(loginButton, { timeout: config.timeout }, { visible: true });
  const loginButtonElement = await page.$x(loginButton);
  await loginButtonElement[0].click();
  await page.waitForSelector(usernameField, { timeout: config.timeout }, { visible: true });

}

async function loginToLO(page, username, password){
  await page.waitForSelector(usernameField, { timeout: config.timeout }, { visible: true });
  await page.type(usernameField, username);
  await page.type(passwordField, password);
  await page.click(submitButton);
  await page.waitForSelector(broadCastButton, { timeout: config.timeout }, { visible: true });

}

async function logoutLO(page){
  await page.waitForSelector(userProfileButton, { timeout: config.timeout }, { visible: true });
  await page.click(userProfileButton);
  await page.waitForSelector(signOutButton, { timeout: config.timeout }, { visible: true });
  await page.click(signOutButton);
  await page.waitForXPath(loginButton, { timeout: config.timeout }, { visible: true });

}

async function verifyComposeAsDeaultSectionOnLogin(page){
  await page.waitForSelector(broadCastButton, { timeout: config.timeout }, { visible: true });
  const composePage = await page.$eval(broadCastButton, el => el.getAttribute("aria-current"));
  return composePage;

}

async function navigateToCompose(page){
  await page.waitForXPath(composeButton, { timeout: config.timeout }, { visible: true });
  const composeButtonElement = await page.$x(composeButton);
  await composeButtonElement[0].click();
  await page.waitForXPath(composeTabPanel, { timeout: config.timeout }, { visible: true });
  await page.waitFor(1500);

}

async function navigateToHistory(page){
  await page.waitForXPath(historyButton, { timeout: config.timeout }, { visible: true });
  const historyButtonElement = await page.$x(historyButton);
  await historyButtonElement[0].click();

}

async function navigateToTemplates(page){
  await page.waitForXPath(templatesButton, { timeout: config.timeout }, { visible: true });
  const templatesButtonElement = await page.$x(templatesButton);
  await templatesButtonElement[0].click();

}

async function clickBroadcastButton(page){
  await page.waitForSelector(broadCastButton, { timeout: config.timeout }, { visible: true });
  await page.click(broadCastButton);

}

async function clickAddTemplate(page){
  await page.waitForXPath(addTemplateButton, { timeout: config.timeout }, { visible: true });
  await page.waitFor(1000);
  const addTemplateButtonElement = await page.$x(addTemplateButton);
  await addTemplateButtonElement[0].click();

}

async function clickSaveButton(page){
  await page.waitForXPath(saveButton, { timeout: config.timeout }, { visible: true });
  const saveButtonElement = await page.$x(saveButton);
  await saveButtonElement[0].click();

}

async function clickCloseButton(page){
  await page.waitForXPath(closeButton, { timeout: config.timeout }, { visible: true });
  const closeButtonElement = await page.$x(closeButton);
  await closeButtonElement[0].click();
  await page.waitFor(1000);

}

async function clickXCloseButton(page){
  await page.waitForSelector(xCloseButton, { timeout: config.timeout }, { visible: true });
  await page.click(xCloseButton);
  await page.waitFor(1000);

}

async function fillInAddTemplateDetails(page, messageType){
  var randomNumber = Math.floor((Math.random() * 10000) + 1);
  var templateName = "Auto Template Name "+randomNumber;
  var templateTitle = "Auto Template Title "+randomNumber;
  await page.waitForXPath(saveButton, { timeout: config.timeout }, { visible: true });
  await page.type(templateNameField, templateName);
  await page.type(templateTitleField, templateTitle);

  const templateMessageTypeFieldElement = await page.$x(templateMessageTypeField);
  await templateMessageTypeFieldElement[0].type(messageType);
  await page.keyboard.press('Enter');
  await page.waitFor(1000);

  await page.type(templateMessageField, "Auto Template Message");

  return {
    templateName,
    templateTitle
  };
}

async function verifyTemplateMessageLength(page){
  await page.waitForSelector(templateMessageField, { timeout: config.timeout }, { visible: true });
  const templateMessageFieldLength = await page.$eval(templateMessageField, el => el.getAttribute("maxlength"));
  return templateMessageFieldLength;

}

async function refreshButtonAndTimeDisplayedOnTemplate(page){
  await page.waitForXPath(refreshButtonOnTemplate, { timeout: config.timeout }, { visible: true });
  const refreshButtonOnTemplateElement = await page.$x(refreshButtonOnTemplate);
  await refreshButtonOnTemplateElement[0].click();

  await page.waitFor(2000);

  const timeDisplayedOnTemplateElement = await page.$x(timeDisplayedOnTemplate);
  var getTextJSon = await timeDisplayedOnTemplateElement[0].getProperty('textContent');
  var displayedTime = await getTextJSon.jsonValue();
  
  return displayedTime;
}

async function openTemplateFromList(page, templateName){
  await page.waitForXPath("//a[contains(@href,'broadcast')][text()='"+templateName+"']", { timeout: config.timeout }, { visible: true });
  const templateNameElement = await page.$x("//a[contains(@href,'broadcast')][text()='"+templateName+"']");
  await templateNameElement[0].click();
  
  await page.waitForXPath(saveButton, { timeout: config.timeout }, { visible: true });

  const openedTemplateNameText = await page.$eval(templateNameField, el => el.getAttribute("value"));
  return openedTemplateNameText;
}

async function editTemplateName(page){
  var randomNumber = Math.floor((Math.random() * 10000) + 1);
  var templateName = "Auto Template Name "+randomNumber;
  await page.waitForXPath(saveButton, { timeout: config.timeout }, { visible: true });
  await helperFuncs.clearText(page, templateNameField);
  await page.waitFor(500);
  await page.type(templateNameField, templateName);

  return templateName;
}

async function deleteTemplate(page){
  await page.waitForSelector(deleteBroadcastButton, { timeout: config.timeout }, { visible: true });
  await page.click(deleteBroadcastButton);
  await page.waitForSelector(confirmButton, { timeout: config.timeout }, { visible: true });
  await page.click(confirmButton);
  await page.waitFor(1000);
  
}

async function selectTemplateAndAddNotesForCompose(page, templateName){
  await page.waitForXPath(templateNameDropdown, { timeout: config.timeout }, { visible: true });
  const templateNameDropdownElement = await page.$x(templateNameDropdown);
  await templateNameDropdownElement[0].type(templateName);
  await page.keyboard.press('Enter');
  await page.waitFor(500);
  await page.waitForSelector(notesField, { timeout: config.timeout }, { visible: true });
  await page.type(notesField, "Auto Broadcast");

}

async function clickNextButton(page){
  await page.waitForXPath(nextButton, { timeout: config.timeout }, { visible: true });
  const nextButtonElement = await page.$x(nextButton);
  await nextButtonElement[0].click();

}

async function clickBackButton(page){
  await page.waitForXPath(backButton, { timeout: config.timeout }, { visible: true });
  const backButtonElement = await page.$x(backButton);
  await backButtonElement[0].click();

}

async function clickCancelButton(page){
  await page.waitForXPath(cancelButton, { timeout: config.timeout }, { visible: true });
  const cancelButtonElement = await page.$x(cancelButton);
  await cancelButtonElement[0].click();

}

async function clickSendButton(page){
  await page.waitForXPath(sendButton, { timeout: config.timeout }, { visible: true });
  const sendButtonElement = await page.$x(sendButton);
  await sendButtonElement[0].click();

}

async function clickViewFullBroadcastButton(page){
  await page.waitForXPath(viewFullBroadcastButton, { timeout: config.timeout }, { visible: true });
  const viewFullBroadcastButtonElement = await page.$x(viewFullBroadcastButton);
  await viewFullBroadcastButtonElement[0].click();

}

async function clickConfirmButton(page){
  await page.waitForSelector(confirmButton, { timeout: config.timeout }, { visible: true });
  await page.click(confirmButton);
  await page.waitFor(1000);

}

async function changeMessageTypeOnCompose(page, messageType){
  await page.waitForXPath(clearButtonMessageType, { timeout: config.timeout }, { visible: true });
  const clearButtonMessageTypeElement = await page.$x(clearButtonMessageType);
  await clearButtonMessageTypeElement[0].click();
  await page.waitFor(1000);

  const templateMessageTypeFieldElement = await page.$x(templateMessageTypeField);
  await templateMessageTypeFieldElement[0].type(messageType);
  await page.keyboard.press('Enter');
  await page.waitFor(1000);

}

async function fillInTargetUsersFilter(page, status, languages, skills){
  await page.waitForXPath(statusDropdownCompose, { timeout: config.timeout }, { visible: true });

  if (status) {
    const statusDropdownComposeElement = await page.$x(statusDropdownCompose);
    await statusDropdownComposeElement[0].type(status);
    await page.keyboard.press('Enter');
    await page.waitFor(500);
  }

  if (languages) {
    const languagesDropdownComposeElement = await page.$x(languagesDropdownCompose);
    await languagesDropdownComposeElement[0].type(languages);
    await page.keyboard.press('Enter');
    await page.waitFor(500);
  }

  if (skills) {
    const skillsDropdownComposeElement = await page.$x(skillsDropdownCompose);
    await skillsDropdownComposeElement[0].type(skills);
    await page.keyboard.press('Enter');
    await page.waitFor(500);
  }

}

async function clickClearFilterButton(page){
  await page.waitForXPath(clearFilterButton, { timeout: config.timeout }, { visible: true });
  const clearFilterButtonElement = await page.$x(clearFilterButton);
  await clearFilterButtonElement[0].click();

}

async function clickOnFirstRecordInHistory(page){
  await page.waitForXPath(firstRecordInHistory, { timeout: config.timeout }, { visible: true });
  const firstRecordInHistoryElement = await page.$x(firstRecordInHistory);
  await firstRecordInHistoryElement[0].click();
  await page.waitForSelector(headerDialogBroadcastDetails, { timeout: config.timeout }, { visible: true });

}

async function navigateToGeneral(page){
  await page.waitForXPath(generalButton, { timeout: config.timeout }, { visible: true });
  const generalButtonElement = await page.$x(generalButton);
  await generalButtonElement[0].click();

}

async function navigateToTarget(page){
  await page.waitForXPath(targetButton, { timeout: config.timeout }, { visible: true });
  const targetButtonElement = await page.$x(targetButton);
  await targetButtonElement[0].click();

}

async function navigateToFinalUsers(page){
  await page.waitForXPath(finalUsersButton, { timeout: config.timeout }, { visible: true });
  const finalUsersButtonElement = await page.$x(finalUsersButton);
  await finalUsersButtonElement[0].click();

}

async function searchUsernameFinalUsers(page, username){
  await page.waitForSelector(searchUsernameField, { timeout: config.timeout }, { visible: true });
  await helperFuncs.clearText(page, searchUsernameField);
  await page.waitFor(200);
  await page.type(searchUsernameField, username);
  await page.waitFor(1500);

}

async function clickNextBroadcastDetailsButton(page){
  await page.waitForXPath(nextButton, { timeout: config.timeout }, { visible: true });
  const nextButtonElement = await page.$x(nextButton);
  await nextButtonElement[0].click();

}

async function clickPreviousBroadcastDetailsButton(page){
  await page.waitForXPath(previousButton, { timeout: config.timeout }, { visible: true });
  const previousButtonElement = await page.$x(previousButton);
  await previousButtonElement[0].click();

}

async function clickSortByDateButton(page){
  await page.waitForXPath(sortByDateButton, { timeout: config.timeout }, { visible: true });
  const sortByDateButtonElement = await page.$x(sortByDateButton);
  await sortByDateButtonElement[0].click();
  await page.waitFor(1500);

}

async function clickSortByTitleButton(page){
  await page.waitForXPath(sortByTitleButton, { timeout: config.timeout }, { visible: true });
  const sortByTitleButtonElement = await page.$x(sortByTitleButton);
  await sortByTitleButtonElement[0].click();
  await page.waitFor(1500);

}

async function clickSortByStatusButton(page){
  await page.waitForXPath(sortByStatusButton, { timeout: config.timeout }, { visible: true });
  const sortByStatusButtonElement = await page.$x(sortByStatusButton);
  await sortByStatusButtonElement[0].click();
  await page.waitFor(1500);

}

async function clickSortByNotesButton(page){
  await page.waitForXPath(sortByNotesButton, { timeout: config.timeout }, { visible: true });
  const sortByNotesButtonElement = await page.$x(sortByNotesButton);
  await sortByNotesButtonElement[0].click();
  await page.waitFor(1500);

}

async function clickHideFilterButton(page){
  await page.waitForXPath(hideFilterTabButton, { timeout: config.timeout }, { visible: true });
  const hideFilterTabButtonElement = await page.$x(hideFilterTabButton);
  await hideFilterTabButtonElement[0].click();
  await page.waitFor(1000);

}

async function clickUnhideFilterButton(page){
  await page.waitForXPath(unhideFilterTabButton, { timeout: config.timeout }, { visible: true });
  const unhideFilterTabButtonElement = await page.$x(unhideFilterTabButton);
  await unhideFilterTabButtonElement[0].click();
  await page.waitFor(1000);

}

async function clickApplyFilterButton(page){
  await page.waitForXPath(applyFilterButton, { timeout: config.timeout }, { visible: true });
  const applyFilterButtonElement = await page.$x(applyFilterButton);
  await applyFilterButtonElement[0].click();
  await page.waitFor(2000);

}

async function clickResetFilterButton(page){
  await page.waitForXPath(resetFilterButton, { timeout: config.timeout }, { visible: true });
  const resetFilterButtonElement = await page.$x(resetFilterButton);
  await resetFilterButtonElement[0].click();
  await page.waitFor(500);

}

async function fillInHistoryFilter(page, status, languages){
  await page.waitForXPath(statusDropdownFilter, { timeout: config.timeout }, { visible: true });
  const statusDropdownFilterElement = await page.$x(statusDropdownFilter);
  await statusDropdownFilterElement[0].type(status);
  await page.keyboard.press('Enter');
  await page.waitFor(500);

  const languagesDropdownFilterElement = await page.$x(languagesDropdownFilter);
  await languagesDropdownFilterElement[0].type(languages);
  await page.keyboard.press('Enter');
  await page.waitFor(500);

}


module.exports = {
  badLogin,
  clickOnForgotPassword,
  enterUsernameAndClickSubmitForgotPassword,
  clickBackToLogin,
  clickLogin,
  loginToLO,
  logoutLO,
  verifyComposeAsDeaultSectionOnLogin,
  navigateToCompose,
  navigateToHistory,
  navigateToTemplates,
  clickBroadcastButton,
  clickAddTemplate,
  clickSaveButton,
  clickCloseButton,
  clickXCloseButton,
  fillInAddTemplateDetails,
  verifyTemplateMessageLength,
  refreshButtonAndTimeDisplayedOnTemplate,
  openTemplateFromList,
  editTemplateName,
  deleteTemplate,
  selectTemplateAndAddNotesForCompose,
  clickNextButton,
  clickBackButton,
  clickCancelButton,
  clickSendButton,
  clickViewFullBroadcastButton,
  clickConfirmButton,
  changeMessageTypeOnCompose,
  fillInTargetUsersFilter,
  clickClearFilterButton,
  clickOnFirstRecordInHistory,
  navigateToGeneral,
  navigateToTarget,
  navigateToFinalUsers,
  searchUsernameFinalUsers,
  clickNextBroadcastDetailsButton,
  clickPreviousBroadcastDetailsButton,
  clickSortByDateButton,
  clickSortByTitleButton,
  clickSortByStatusButton,
  clickSortByNotesButton,
  clickHideFilterButton,
  clickUnhideFilterButton,
  clickApplyFilterButton,
  clickResetFilterButton,
  fillInHistoryFilter,
  broadCastButton,
  invalidLoginMesaage,
  targetUsersHeader,
  finalBroadcastReviewHeader,
  viewFullBroadcastButton,
  statusDefaultValueCompose,
  teamDefaultValueCompose,
  languagesDefaultValueCompose,
  skillsDefaultValueCompose,
  typeDefaultValueCompose,
  searchUsernameField
  
 }