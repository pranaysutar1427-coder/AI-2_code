var config = require('../config');

const delay = milliseconds => {
    return new Promise(resolve => setTimeout(resolve, milliseconds));
  };

const usernameField = 'input[name="username"]'; //selector
const passwordField = 'input[name="password"]'; //selector
const signInButton = 'button[type="submit"]'; //selector
const stratusLogoImage = 'img[alt="AMN Language Services Logo"]'; //selector
const forgetPasswordButton = '//a[contains(text(),\'Forgot password\')]'; //xpath
const submitButton = 'button[type="submit"]'; //selector
const firstRecordingRow = '//div[@class=\'rt-table\']/div[@class=\'rt-tbody\']/div[1]/div[@role=\'row\']';
const viewListButton = '//a[text()=\'View List\']'; //xpath
const sessionFilterButton = '//span[text()=\'Session\']//following::i[1][@class=\'filter icon\']'; //xpath
const legFilterButton = '//span[text()=\'Leg\']//following::i[1][@class=\'filter icon\']'; //xpath
const startFilterButton = '//span[text()=\'Start\']//following::i[1][@class=\'filter icon\']'; //xpath
const startSortButton = '//div[@role=\'columnheader\']//span[text()=\'Start\']'; //xpath
const lengthFilterButton = '//span[text()=\'Length\']//following::i[1][@class=\'filter icon\']'; //xpath
const accountFilterButton = '//span[text()=\'Account\']//following::i[1][@class=\'filter icon\']'; //xpath
const usernameFilterButton = '//span[text()=\'Username\']//following::i[1][@class=\'filter icon\']'; //xpath
const teamFilterButton = '//span[text()=\'Team\']//following::i[1][@class=\'filter icon\']'; //xpath
const mediaFilterButton = '//span[text()=\'Media\']//following::i[1][@class=\'filter icon\']'; //xpath
const reviewedFilterButton = '//span[text()=\'Reviewed\']//following::i[1][@class=\'filter icon\']'; //xpath
const selectOperatorDropdown = '//div[@name=\'operator\']'; //xpath
const equalsOptionForOperator = '//div[@role=\'option\']//span[text()=\'Equals\']'; //xpath
const valueTextfield = 'input[name="value"][placeholder="Enter value"]'; //selector
const applyButton = '//button[text()=\'Apply\']'; //xpath
const saveFilterButton = 'i[class="save icon"]'; //selector
const deleteFilterButton = 'i[class="trash icon"]'; //selector
const favouriteFilterButton = 'i[class="star icon"]'; //selector
const filterButtonYellow = '//button[@class=\'ui yellow icon button\']'; //xpath
const enterFilterNameTextfield = 'input[name="name"]'; //selector
const filterDropdown = 'input[type="text"][class="search"]'; //selector
const clearFilterOption = '//div[@class=\'visible menu transition\']//span[text()=\'Clear Filters\']'; //xpath
const saveButton = '//button[@type=\'submit\'][text()=\'Save\']'; //xpath
const okButton = '//button[text()=\'OK\']'; //xpath
const firstLegLength = '(//div[@class=\'rt-table\']//div[4][@role=\'gridcell\'])[1]'; //xpath
const sessionStart = '//h4[text()=\'Session Start\']//following::div[1]'; //xpath
const sessionEnd = '//h4[text()=\'Session End\']//following::div[1]'; //xpath
const ratingTextField = 'input[name="rating"]'; //selector
const ratingReasonDropdown = 'div[name="reason"]'; //selector
const routineMonitoringReason = '//span[text()=\'Routine Quality Monitoring\']'; //xpath
const ratingQMTypeDropdown = 'div[name="qm_type"]'; //selector
const presentationQMType = '//span[text()=\'Presentation\']'; //xpath
const successPopup = '//div[@class=\'css-y1cwqx ecpg26w0 pop-enter-done\']'; //xpath
const nextButtonPagination = '//button[@type=\'button\'][text()=\'Next\']'; //xpath
const previousButtonPagination = '//button[@type=\'button\'][text()=\'Previous\']'; //xpath
const pageNumber = 'input[type="number"]'; //selector
const firstLegWithVideo = '(//i[@class=\'video icon\'])[1]//preceding::div[7]/a'; //xpath
const videoScreenshot = 'img[alt="Visual of user from session"]'; //selector
const workforceTab = '//a[text()=\'Workforce\']'; //xpath
const firstUserOnWorkforce = '//div[1][@role=\'rowgroup\']//a[1]'; //xpath
const workforceUsernameColumn = '//div[@role=\'columnheader\']//span[text()=\'Username\']'; //xpath
const workforceFirstNameColumn = '//div[@role=\'columnheader\']//span[text()=\'First Name\']'; //xpath
const workforceLastNameColumn = '//div[@role=\'columnheader\']//span[text()=\'Last Name\']'; //xpath
const workforceEmailColumn = '//div[@role=\'columnheader\']//span[text()=\'Email\']'; //xpath
const workforceTypeColumn = '//div[@role=\'columnheader\']//span[text()=\'Type\']'; //xpath
const workforceTeamColumn = '//div[@role=\'columnheader\']//span[text()=\'Team\']'; //xpath
const workforceUserStartColumn = '//div[@role=\'columnheader\']//span[text()=\'User Start\']'; //xpath
const workforceLastSessionColumn = '//div[@role=\'columnheader\']//span[text()=\'Last Session\']'; //xpath
const workforceActiveColumn = '//div[@role=\'columnheader\']//span[text()=\'Active\']'; //xpath
const workforceLastReviewedColumn = '//div[@role=\'columnheader\']//span[text()=\'Last Reviewed\']'; //xpath
const workforceReviewsColumn = '//div[@role=\'columnheader\']//span[text()=\'Reviews\']'; //xpath
const workforceAverageRatingColumn = '//div[@role=\'columnheader\']//span[text()=\'Average Rating\']'; //xpath




async function loginToQM(page, username, password){
    await page.type(usernameField, username);
    await page.type(passwordField, password);
    await page.click(signInButton);
    await page.waitForSelector(stratusLogoImage);
}

async function clickForgetPassword(page){
  const locatorObject = await page.$x(forgetPasswordButton);
  await locatorObject[0].click();
}

async function enterUsernameClickSubmitForgetPassword(page, username){
  await page.type(usernameField, username);
  await page.click(submitButton);
}

async function verifyLatestSessionLegs(page){

  await page.waitForXPath(firstRecordingRow, { timeout: config.timeout }, { visible: true });
  
}

async function clickViewListButton(page){
  const locatorObject = await page.$x(viewListButton);
  await locatorObject[0].click();
}

//rowCount = 5 rows, 10 rows, 20 rows, 25 rows, 50 rows
async function changeRowsCount(page, rowCount){
  
  await delay(2000);
  const rowDropdown = await page.$x("//span[@class='select-wrap -pageSizeOptions']//select");
  await rowDropdown[0].type(rowCount);
  await delay(2000);
  
}

async function clickOnLegForUsername(page, username){

  await delay(1000);

  await page.waitForXPath("//div[@class='rt-table']", { timeout: config.timeout }, { visible: true });
  
  const userNameObject = await page.$x("//div[@class='rt-table']//div[6][@role='gridcell']");
  const legObject = await page.$x("//div[@class='rt-table']//div[2][@role='gridcell']/a");

  var i;
  for (i = 0; i < userNameObject.length; i++) {

    var getTextJSon = await userNameObject[i].getProperty('textContent');
    var userNameText = await getTextJSon.jsonValue();

    if (userNameText === username) {
      await legObject[i].click();
      await page.waitForXPath(viewListButton, { timeout: config.timeout }, { visible: true });
      break;
    }
  }
  
}

async function verifyStartColoumnSorting(page){

  await page.waitForXPath(startSortButton, { timeout: config.timeout }, { visible: true });

  const startSortButtonObj = await page.$x(startSortButton);
  await startSortButtonObj[0].click();
}

async function createUsernameFilter(page, username){

  await page.waitForXPath(usernameFilterButton, { timeout: config.timeout }, { visible: true });

  const usernameFilterButtonObj = await page.$x(usernameFilterButton);
  await usernameFilterButtonObj[0].click();

  await page.waitForXPath(selectOperatorDropdown, { timeout: config.timeout }, { visible: true });

  const selectOperatorDropdownObj = await page.$x(selectOperatorDropdown);
  await selectOperatorDropdownObj[0].click();

  const equalsOptionForOperatorObj = await page.$x(equalsOptionForOperator);
  await equalsOptionForOperatorObj[0].click();

  await page.evaluate(valueTextfield => { document.querySelector(valueTextfield).value = ""; }, valueTextfield);
  await page.type(valueTextfield, username);

  const applyButtonObj = await page.$x(applyButton);
  await applyButtonObj[0].click();
  
}

async function createUsernameFilterAndSave(page, username){

  await createUsernameFilter(page, username);

  await page.waitForSelector(saveFilterButton, { timeout: config.timeout }, { visible: true });
  await page.click(saveFilterButton);

  var filterName = "Auto Test "+Math.floor((Math.random() * 10000) + 1);

  await page.type(enterFilterNameTextfield, filterName);

  const saveButtonObj = await page.$x(saveButton);
  await saveButtonObj[0].click();

  return filterName;
  
}

async function verifyFavouriteFilter(page){

  await delay(2000);
  await page.waitForSelector(favouriteFilterButton, { timeout: config.timeout }, { visible: true });
  await page.click(favouriteFilterButton);
  await page.waitForXPath(filterButtonYellow, { timeout: config.timeout }, { visible: true });
  await page.reload();
  await delay(5000);
  
}

async function deleteAndClearFilter(page){

  await delay(2000);

  await page.waitForSelector(deleteFilterButton, { timeout: config.timeout }, { visible: true });
  await page.click(deleteFilterButton);

  await page.waitForXPath(okButton, { timeout: config.timeout }, { visible: true });
  const okButtonObj = await page.$x(okButton);
  await okButtonObj[0].click();

  await clearFilter(page);
  
}

async function clearFilter(page){

  await delay(2000);

  await page.waitForSelector(filterDropdown, { timeout: config.timeout }, { visible: true });
  await page.click(filterDropdown);

  await page.waitForXPath(clearFilterOption, { timeout: config.timeout }, { visible: true });
  const clearFilterOptionObj = await page.$x(clearFilterOption);
  await clearFilterOptionObj[0].click();

  await delay(2000);
  
}

async function verifyLengthOfCallDispalyed(page){

  await page.waitForXPath(firstLegLength, { timeout: config.timeout }, { visible: true });
  const firstLegLengthObj = await page.$x(firstLegLength);
  var getTextJSon = await firstLegLengthObj[0].getProperty('textContent');
  var length = await getTextJSon.jsonValue();
  
  return length;

}

async function verifyStartAndEndDate(page){

  await page.waitForXPath(sessionStart, { timeout: config.timeout }, { visible: true });
  const sessionStartObj = await page.$x(sessionStart);
  var getTextJSonStart = await sessionStartObj[0].getProperty('textContent');
  var startDateTime = await getTextJSonStart.jsonValue();
  await expect(startDateTime).toEqual(startDateTime);

  await page.waitForXPath(sessionEnd, { timeout: config.timeout }, { visible: true });
  const sessionEndObj = await page.$x(sessionEnd);
  var getTextJSonEnd = await sessionEndObj[0].getProperty('textContent');
  var endDateTime = await getTextJSonEnd.jsonValue();
  await expect(endDateTime).toEqual(endDateTime);

}


async function verifyRatingALeg(page){

  await delay(2000);
  await page.waitForSelector(ratingTextField, { timeout: config.timeout }, { visible: true });
  await page.evaluate(ratingTextField => { document.querySelector(ratingTextField).value = ""; }, ratingTextField);
  var rating = Math.floor((Math.random() * 100) + 1).toString();
  await page.type(ratingTextField, rating, { clear : true });

  await delay(1000);

  await page.waitForSelector(ratingReasonDropdown, { timeout: config.timeout }, { visible: true });
  await page.click(ratingReasonDropdown);

  await page.waitForXPath(routineMonitoringReason, { timeout: config.timeout }, { visible: true });
  const routineMonitoringReasonObj = await page.$x(routineMonitoringReason);
  await routineMonitoringReasonObj[0].click();

  await page.waitForSelector(ratingQMTypeDropdown, { timeout: config.timeout }, { visible: true });
  await page.click(ratingQMTypeDropdown);

  await page.waitForXPath(presentationQMType, { timeout: config.timeout }, { visible: true });
  const presentationQMTypeObj = await page.$x(presentationQMType);
  await presentationQMTypeObj[0].click();

  await page.waitForXPath(saveButton, { timeout: config.timeout }, { visible: true });
  const saveButtonObj = await page.$x(saveButton);
  await saveButtonObj[0].click();

  await page.waitForXPath(successPopup, { timeout: config.timeout }, { visible: true });

}

async function verifyNextPagination(page){

  await delay(1000);
  await page.waitForXPath(nextButtonPagination, { timeout: config.timeout }, { visible: true });
  const nextButtonPaginationObj = await page.$x(nextButtonPagination);
  await nextButtonPaginationObj[0].click();

  await page.waitForSelector(pageNumber, { timeout: config.timeout }, { visible: true });
  var pageNumberAfterNext = await page.$eval(pageNumber, element=> element.getAttribute("value"));

  return pageNumberAfterNext;
  
}

async function verifyPreviousPagination(page){

  await delay(2000);
  await page.waitForXPath(previousButtonPagination, { timeout: config.timeout }, { visible: true });
  const previousButtonPaginationObj = await page.$x(previousButtonPagination);
  await previousButtonPaginationObj[0].click();

  await delay(2000);

  await page.waitForSelector(pageNumber, { timeout: config.timeout }, { visible: true });
  var pageNumberAfterPrevious = await page.$eval(pageNumber, element=> element.getAttribute("value"));

  return pageNumberAfterPrevious;
  
}

async function clickOnFirstLegWithVideo(page){

  await page.waitForXPath(firstLegWithVideo, { timeout: config.timeout }, { visible: true });
  const firstLegWithVideoObj = await page.$x(firstLegWithVideo);
  await firstLegWithVideoObj[0].click();
  
}

async function verifyImageScreenshot(page){

  await page.waitForSelector(videoScreenshot, { timeout: config.timeout }, { visible: true });
  await expect(page).toMatchElement(videoScreenshot, { timeout : config.timeout }, { visible: true });
  
}

async function navigateToWorkforceTab(page){

  await page.waitForXPath(workforceTab, { timeout: config.timeout }, { visible: true });
  const workforceTabObj = await page.$x(workforceTab);
  await workforceTabObj[0].click();
  
}


async function createUsernameFilterForWorkforce(page, username){

  await delay(2000)
  await page.waitForXPath(usernameFilterButton, { timeout: config.timeout }, { visible: true });

  const usernameFilterButtonObj = await page.$x(usernameFilterButton);
  await usernameFilterButtonObj[0].click();

  await page.waitForXPath(selectOperatorDropdown, { timeout: config.timeout }, { visible: true });

  const selectOperatorDropdownObj = await page.$x(selectOperatorDropdown);
  await selectOperatorDropdownObj[0].click();

  const equalsOptionForOperatorObj = await page.$x(equalsOptionForOperator);
  await equalsOptionForOperatorObj[0].click();

  await page.evaluate(valueTextfield => { document.querySelector(valueTextfield).value = ""; }, valueTextfield);
  await page.type(valueTextfield, username);

  const applyButtonObj = await page.$x(applyButton);
  await applyButtonObj[0].click();
  
}

async function clickOnFirstUsernameOnWorkforce(page){

  await delay(2000);
  await page.waitForXPath(firstUserOnWorkforce, { timeout: config.timeout }, { visible: true });
  const firstUserOnWorkforceObj = await page.$x(firstUserOnWorkforce);
  await firstUserOnWorkforceObj[0].click();
  await delay(2000);
  
}

async function saveFilterForWorkforce(page){

  await page.waitForSelector(saveFilterButton, { timeout: config.timeout }, { visible: true });
  await page.click(saveFilterButton);

  var filterName = "Auto Test "+Math.floor((Math.random() * 10000) + 1);

  await page.type(enterFilterNameTextfield, filterName);

  const saveButtonObj = await page.$x(saveButton);
  await saveButtonObj[0].click();

  return filterName;
  
}

async function deleteAndClearFilterForWorkforce(page){

  await delay(2000);

  await page.waitForSelector(deleteFilterButton, { timeout: config.timeout }, { visible: true });
  await page.click(deleteFilterButton);

  await page.waitForXPath(okButton, { timeout: config.timeout }, { visible: true });
  const okButtonObj = await page.$x(okButton);
  await okButtonObj[0].click();

  await delay(2000);

  await page.waitForSelector(filterDropdown, { timeout: config.timeout }, { visible: true });
  await page.click(filterDropdown);

  await page.waitForXPath(clearFilterOption, { timeout: config.timeout }, { visible: true });
  const clearFilterOptionObj = await page.$x(clearFilterOption);
  await clearFilterOptionObj[0].click();

  await delay(2000);
  
}

module.exports = { 
    loginToQM,
    clickForgetPassword,
    enterUsernameClickSubmitForgetPassword,
    verifyLatestSessionLegs,
    clickOnLegForUsername,
    clickViewListButton,
    changeRowsCount,
    verifyStartColoumnSorting,
    createUsernameFilter,
    createUsernameFilterAndSave,
    deleteAndClearFilter,
    clearFilter,
    verifyRatingALeg,
    verifyNextPagination,
    verifyPreviousPagination,
    clickOnFirstLegWithVideo,
    verifyImageScreenshot,
    verifyLengthOfCallDispalyed,
    verifyStartAndEndDate,
    verifyFavouriteFilter,
    navigateToWorkforceTab,
    clickOnFirstUsernameOnWorkforce,
    createUsernameFilterForWorkforce,
    saveFilterForWorkforce,
    deleteAndClearFilterForWorkforce,
    stratusLogoImage,
    workforceUsernameColumn,
    workforceFirstNameColumn,
    workforceLastNameColumn,
    workforceEmailColumn,
    workforceTypeColumn,
    workforceTeamColumn,
    workforceUserStartColumn,
    workforceLastSessionColumn,
    workforceActiveColumn,
    workforceLastReviewedColumn,
    workforceReviewsColumn,
    workforceAverageRatingColumn,
    sessionFilterButton,
    legFilterButton,
    startFilterButton,
    lengthFilterButton,
    accountFilterButton,
    usernameFilterButton,
    teamFilterButton,
    mediaFilterButton,
    reviewedFilterButton,

    
 }