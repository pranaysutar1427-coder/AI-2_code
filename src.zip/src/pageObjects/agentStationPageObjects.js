var config = require('../config');

const Delay = milliseconds => {
    return new Promise(resolve => setTimeout(resolve, milliseconds));
  };

const usernameField = 'input[name="username"]'; //selector
const passwordField = 'input[name="password"]'; //selector
const signInButton = 'button[type="submit"]'; //selector
const logoutButton = "//div[@class='operatorName']//span[text()='Logout']";
const confirmLogoutModal = '#logoutModal';
const confirmLogoutButton = 'a[data-e2e="logout"]';
const usernameText = '//div[@class=\'header-username\']'; //xpath
const userStatus = '//button[@class=\'operatorStatus\']//span'; //xpath
const statusButton = '//button[@class=\'operatorStatus\']'; //xpath
const supportButton = '//a[text()=\'Support\']'; //xpath
const settingsButton = '//a[text()=\'Settings\']'; //xpath
const contactTabButton = '//li[text()=\'Contact\']'; //xpath
const mediaDiagnosticsTabButton = '//li[text()=\'Media Diagnostics\']'; //xpath
const speedTestTabButton = '//li[text()=\'Speed Test\']'; //xpath
const contactPhoneText = '//strong[contains(text(),\'Phone\')]'; //xpath
const contactEmailText = '//strong[contains(text(),\'E-mail\')]'; //xpath
const microphoneAudioVisualizer = 'canvas[class="audio-visualizer"]'; //selector
const yesButton = '//button[text()=\'Yes\']'; //xpath
const testRingSettingsButton = '//button[text()=\'Test Ring Settings\']'; //xpath
const stopRingButton = '//button[text()=\'Stop\']'; //xpath
const callAcceptButton = "//span[text()='Accept']"; //xpath
const callSessionVideo = '#remoteVideo'; //selector
const sendChatMessageTextarea = '//textarea[@id=\'chatPanelTextInput\']'; //xpath
const displayTextButton = '//button[text()=\'Display Text\']'; //xpath
const clientChatDisplay = '//div[@class=\'video-textOverlayContent\']//div'; //xpath
const reportIncidentButton = '//a[text()=\'Report Incident\']'; //xpath
const reportIncidentCommnentTextarea = "//span[text()='Comments']//following::textarea[1]"; //xpath
const reportIncidentCommentTextareaAsterisk = "//span[text()='Comments']//preceding::span[1]";
const submitButton = '//button[@type=\'button\']//span[text()=\'Submit\']';
const sessionNotesButton = '//span[text()=\'Session Notes\']'; //xpath
const sessionNotesTextarea = 'input[name="sessionNoteInput"]';
const postButton = "//button[@type='submit'][text()='Post']"; //xpath
const sessionNotesConversation = 'div[class="conversation conversation-new"]';
const clientSettingsButton = '//span[contains(text(),\'Client Settings\')]';
const videoRefreshButton = 'a[data-e2e="refresh"]';
const endCallButton = 'a[class="controls-end"]';
const callDetailsInfo = 'section[class="clearfix waitscreen-callInfo info"]';
const add30SecondsButton = '//i[@class=\'fa fa-plus\'][contains(text(),\'Add 30 seconds\')]';
const secondsTimer = '//section[@class=\'callInfo fullWidth public\']/h1/span[2]';
const skipToStationButton = '//i[@class=\'fa fa-arrow-right\'][contains(text(),\'Skip to station\')]';
const submitButtonBillingQuestion = "//button[text()='Submit']";
const freeFormQuestion = "//span[text()='Automation Free Form']//following::input[1]";
const dateQuestion = "//span[text()='Automation Date']//following::input[1]";
const booleanQuestion = 'div.fieldGroup.fullWidth.has-success:nth-child(3) > select.form-control:nth-child(2)';
const transferButton = 'button[data-e2e="transfer"]';
const refreshListButton = "//span[contains(text(),'Refresh List')]";
const availableTerpListDropdown = 'div.modal-body.transfer div.form-group:nth-child(1) > select.form-control';
const textareaTransferNotes = 'textarea[name="notes"]';
const dialogTransferButton = "//div[@class='modal-footer transfer']//span[text()='Transfer']";
const transferRequestNotificationModal = '#transferDecisionModalLabel';
const requeueButton = 'button[data-e2e="requeue"]';
const requeueModal = '#requeueModalLabel';
const languageDropdownForRequeue = "//label[text()='Language']//following::div[@class='Select-input '][1]";
const dialogRequeueButton = "//div[@class='modal-footer transfer']//span[text()='Requeue']";
const requeueRequestNotificationModal = '#incomingCall';


async function loginToAWS(page, username, password){
  await page.waitForSelector(usernameField, { timeout: config.timeout }, { visible: true });
  await page.type(usernameField, username);
  await page.type(passwordField, password);
  await page.click(signInButton);
  await page.waitForXPath(usernameText);
  await Delay(2000);
}

async function logoutToAWS(page){
  await page.waitFor(1000);
  await page.waitForXPath(statusButton, { timeout: config.timeout }, { visible: true });
  const statusButtonObj = await page.$x(statusButton);
  await statusButtonObj[0].click();
  await page.waitFor(1000);
  await page.waitForXPath(logoutButton, { timeout: config.timeout }, { visible: true });
  const logoutElement = await page.$x(logoutButton);
  await logoutElement[0].click();
  await page.waitForSelector(confirmLogoutModal, { timeout: config.timeout }, { visible: true });
  await page.click(confirmLogoutButton);
  await page.waitForSelector(usernameField, { timeout: config.timeout }, { visible: true });
}

async function changeUserStatus(page, status){

  await Delay(1000);
  await page.waitForXPath(statusButton, { timeout: config.timeout }, { visible: true });
  const statusButtonObj = await page.$x(statusButton);
  await statusButtonObj[0].click();
  await Delay(1000);
  await page.waitForXPath("//div[@class='operatorName']//span[text()='"+status+"']", { timeout: config.timeout }, { visible: true });
  const toSetStatus = await page.$x("//div[@class='operatorName']//span[text()='"+status+"']");
  await toSetStatus[0].click();
  await Delay(1000);
  await page.waitForXPath(userStatus);

}

async function navigateToSupport(page){
  await page.waitForXPath(supportButton, { timeout: config.timeout }, { visible: true });
  const supportButtonObj = await page.$x(supportButton);
  await supportButtonObj[0].click();
}

async function navigateToSettings(page){
  await page.waitForXPath(settingsButton, { timeout: config.timeout }, { visible: true });
  const settingsButtonObj = await page.$x(settingsButton);
  await settingsButtonObj[0].click();
}

async function navigateToContactTab(page){
  await page.waitForXPath(contactTabButton, { timeout: config.timeout }, { visible: true });
  const contactTabButtonObj = await page.$x(contactTabButton);
  await contactTabButtonObj[0].click();

}

async function navigateToMediaDiagnosticsTab(page){
  await page.waitForXPath(mediaDiagnosticsTabButton, { timeout: config.timeout }, { visible: true });
  const mediaDiagnosticsTabButtonObj = await page.$x(mediaDiagnosticsTabButton);
  await mediaDiagnosticsTabButtonObj[0].click();

}

async function navigateToSpeedTestTab(page){
  await page.waitForXPath(speedTestTabButton, { timeout: config.timeout }, { visible: true });
  const speedTestTabButtonObj = await page.$x(speedTestTabButton);
  await speedTestTabButtonObj[0].click();

}

async function clickYesButton(page){
  await page.waitForXPath(yesButton, { timeout: config.timeout }, { visible: true });
  const yesButtonObj = await page.$x(yesButton);
  await yesButtonObj[0].click();

}

async function clickTestRingSettingsButton(page){
  await page.waitForXPath(testRingSettingsButton, { timeout: config.timeout }, { visible: true });
  const testRingSettingsButtonObj = await page.$x(testRingSettingsButton);
  await testRingSettingsButtonObj[0].click();

}

async function clickStopRingButton(page){
  await page.waitForXPath(stopRingButton, { timeout: config.timeout }, { visible: true });
  const stopRingButtonObj = await page.$x(stopRingButton);
  await stopRingButtonObj[0].click();

}

async function awsAcceptCall(page){

  await page.waitForXPath(callAcceptButton, { timeout: config.timeout }, { visible: true });
  const callAcceptButtonObj = await page.$x(callAcceptButton);
  await callAcceptButtonObj[0].click();

  await expect(page).toMatchElement(callSessionVideo, { timeout: config.timeout }, { visible: true });
    
}

async function sendingChatTextMessage(page, textMessage){

  await page.waitForXPath(sendChatMessageTextarea, { timeout: config.timeout }, { visible: true });
  const sendChatMessageTextareaObj = await page.$x(sendChatMessageTextarea);
  await sendChatMessageTextareaObj[0].type(textMessage);

  await page.waitForXPath(displayTextButton, { timeout: config.timeout }, { visible: true });
  const displayTextButtonObj = await page.$x(displayTextButton);
  await displayTextButtonObj[0].click();
    
}

async function navigateToReportIncident(page){
  await page.waitForXPath(reportIncidentButton, { timeout: config.timeout }, { visible: true });
  const reportIncidentButtonObj = await page.$x(reportIncidentButton);
  await reportIncidentButtonObj[0].click();

}

async function submitIncidentReport(page){
  navigateToReportIncident(page);

  await page.waitFor(2000);

  const option1 = (await page.$x('//span[text()=\'Technical Question 1\']//following::select[1]/option[2]'))[0];
  const value1 = await (await option1.getProperty('value')).jsonValue();
  await page.select('select[name="answer-3"]', value1);


  await page.waitForXPath(reportIncidentCommnentTextarea, { timeout: config.timeout }, { visible: true });
  const reportIncidentCommnentTextareaObj = await page.$x(reportIncidentCommnentTextarea);
  await reportIncidentCommnentTextareaObj[0].type('Test Comment Message');

  await page.waitForXPath(submitButton, { timeout: config.timeout }, { visible: true });
  const submitButtonObj = await page.$x(submitButton);
  await submitButtonObj[0].click();

  await page.waitFor(1000);
  
}

async function postSessionNotes(page, notes){
  await page.waitForXPath(sessionNotesButton, { timeout: config.timeout }, { visible: true });
  const sessionNotesButtonObj = await page.$x(sessionNotesButton);
  await sessionNotesButtonObj[0].click();

  await page.waitForSelector(sessionNotesTextarea, { timeout: config.timeout }, { visible: true });
  await page.type(sessionNotesTextarea, notes);

  await page.waitForXPath(postButton, { timeout: config.timeout }, { visible: true });
  const postButtonObj = await page.$x(postButton);
  await postButtonObj[0].click();

}

async function clickClientSettings(page){
  await page.waitForXPath(clientSettingsButton, { timeout: config.timeout }, { visible: true });
  const clientSettingsButtonObj = await page.$x(clientSettingsButton);
  await clientSettingsButtonObj[0].click();

}

async function clickVideoRefreshButton(page){
  await page.waitForSelector(videoRefreshButton, { timeout: config.timeout }, { visible: true });
  await page.hover(videoRefreshButton);
  await page.waitFor(500);
  await page.click(videoRefreshButton);
  await page.waitFor(1000);

}

async function clickEndCallButton(page){
  await page.waitForSelector(endCallButton, { timeout: config.timeout }, { visible: true });
  await page.hover(endCallButton);
  await page.waitFor(500);
  await page.click(endCallButton);
  await page.waitFor(1000);

  await page.waitForXPath("//button[@class='operatorStatus']//div[@class='operatorName']//span[text()='Wrapping']", { timeout: config.timeout }, { visible: true });
}

async function add30SecondsAndCalculate(page){

  await page.waitForXPath(add30SecondsButton, { timeout: config.timeout }, { visible: true });
  const add30SecondsButtonObj = await page.$x(add30SecondsButton);
  const elementXpath = await page.$x(secondsTimer);
  var getTextJSon = await elementXpath[0].getProperty('textContent');
  var currentSeconds = await getTextJSon.jsonValue();
  await add30SecondsButtonObj[0].click();

  var afterAddingSeconds = (parseInt(currentSeconds) + 30).toString();

  return afterAddingSeconds;
}


async function clickSkipToStationButton(page){
  await page.waitForXPath(skipToStationButton, { timeout: config.timeout }, { visible: true });
  const skipToStationButtonObj = await page.$x(skipToStationButton);
  await skipToStationButtonObj[0].click();

  await page.waitForXPath("//button[@class='operatorStatus']//div[@class='operatorName']//span[text()='Available']", { timeout: config.timeout }, { visible: true });

}

async function fillInBillingQuestion(page){
  await page.waitForXPath(submitButtonBillingQuestion, { timeout: config.timeout }, { visible: true });

  const freeFormElement = await page.$x(freeFormQuestion);
  await freeFormElement[0].type('Free Form Answer');

  const dateQuestionElement = await page.$x(dateQuestion);
  await dateQuestionElement[0].click();
  await page.waitFor(1000);
  await dateQuestionElement[0].type('12122012');
  await page.waitFor(1000);
  await page.select(booleanQuestion, 'true');

}

async function clickSubmitBillingQuestion(page){
  await page.waitForXPath(submitButtonBillingQuestion, { timeout: config.timeout }, { visible: true });
  const submitButtonElement = await page.$x(submitButtonBillingQuestion);
  await submitButtonElement[0].click();

}

async function doTransferToTerp(page){
  await page.waitForSelector(transferButton, { timeout: config.timeout }, { visible: true });
  await page.click(transferButton);

  await page.waitForXPath(refreshListButton, { timeout: config.timeout }, { visible: true });
  const refreshListButtonElement = await page.$x(refreshListButton);
  await refreshListButtonElement[0].click();

  const option1 = (await page.$x("//span[contains(text(),'Refresh List')]//following::select[1]/option[2]"))[0];
  const value1 = await (await option1.getProperty('value')).jsonValue();
  await page.select(availableTerpListDropdown, value1);

  await page.type(textareaTransferNotes, 'Transfer Notes');

  const dialogTransferButtonElement = await page.$x(dialogTransferButton);
  await dialogTransferButtonElement[0].click();

}

async function doRequeue(page, language){

  await page.waitForSelector(requeueButton, { timeout: config.timeout }, { visible: true });
  await page.click(requeueButton);

  await page.waitForSelector(requeueModal, { timeout: config.timeout }, { visible: true });
  
  await page.waitForXPath(languageDropdownForRequeue, { timeout: config.timeout }, { visible: true });
  const languageDropdownForRequeueElement = await page.$x(languageDropdownForRequeue);
  await languageDropdownForRequeueElement[0].click();
  await languageDropdownForRequeueElement[0].type(language);
  await page.keyboard.press('Enter');
  
  const dialogRequeueButtonElement = await page.$x(dialogRequeueButton);
  await dialogRequeueButtonElement[0].click();

}


module.exports = { 
    loginToAWS,
    logoutToAWS,
    changeUserStatus,
    navigateToSupport,
    navigateToSettings,
    navigateToContactTab,
    navigateToMediaDiagnosticsTab,
    navigateToSpeedTestTab,
    clickYesButton,
    clickTestRingSettingsButton,
    clickStopRingButton,
    awsAcceptCall,
    sendingChatTextMessage,
    navigateToReportIncident,
    submitIncidentReport,
    postSessionNotes,
    clickClientSettings,
    clickVideoRefreshButton,
    clickEndCallButton,
    add30SecondsAndCalculate,
    clickSkipToStationButton,
    fillInBillingQuestion,
    clickSubmitBillingQuestion,
    doTransferToTerp,
    doRequeue,
    userStatus,
    contactPhoneText,
    contactEmailText,
    microphoneAudioVisualizer,
    clientChatDisplay,
    callSessionVideo,
    callDetailsInfo,
    sessionNotesConversation,
    reportIncidentCommentTextareaAsterisk,
    transferRequestNotificationModal,
    requeueRequestNotificationModal,
    
 }