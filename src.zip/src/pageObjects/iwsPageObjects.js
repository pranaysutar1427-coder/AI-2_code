var config = require('../config');

const delay = milliseconds => {
    return new Promise(resolve => setTimeout(resolve, milliseconds));
  };

const forgotPassword = "//a[contains(@href,'forgot-password')]";
const usernameField = 'input[name="username"]';
const passwordField = 'input[name="password"]';
const passwordResetSubmitButton = 'button[type="submit"]';
const passwordResetMessage = "Please check your email for a reset password link.";
const backToLogin = "//a[text()='Back to Login']";
const outlookEmailField = 'input[type="email"]';
const continueButton = '//button[@type="submit"]';
const outlookSubmitButton = 'input[type="submit"]';
const outlookPasswordField = 'input[type="password"]';
const noButton = 'input[type="button"]';
const outlookHomePageMenuButton = 'button[type="button"]';
const resetPasswordMail = "//span[text()='Stratus Video Password Reset']";
const likeButton = 'i[data-icon-name="Like"]';
const resetPasswordLink = 'Click here to reset your password.';
const resetPasswordText = 'Reset Password';
const newPasswordField = 'input[name="password"]';
const confirmPasswordField = 'input[name="passwordConfirm"]';
const OkButton = 'button[type="button"]';
const signInButton = 'button';
const signoutButton = "//div[@data-e2e='user-menu-item-logout']";
const userDropdown = "//button[@data-e2e='user-menu-button']";
const historyButton = "//div[text()='History']";
const diagnosticButton = "//div[text()='Diagnostics']";
const versionButton = "//button[text()='Version']";
const speedTestButton = "//button[text()='Speed Test']";
const microphoneButton = "//button[text()='Microphone']";
const logoutSuccessMessage = "//p[text()='You've been successfully logged out.']";
const cameraPreviewButton = "//span[text()='Camera Preview']";
const callViewLeftSide = "#session--left-column";
const callViewRightSide = "#session--right-column";
const collapseButton = 'button[aria-label="Collapse"]';
const expandButton = 'button[aria-label="Expand"]';



async function clickOnForgotPassword(page){
    await page.waitForXPath(forgotPassword, { timeout: config.timeout }, { visible: true });
    const forgotPasswordLink = await page.$x(forgotPassword);
    await forgotPasswordLink[0].click();

}

async function clickOnCameraPreview(page){
  await page.waitForXPath(cameraPreviewButton, { timeout: config.timeout }, { visible: true });
  const cameraPreviewButtonObj = await page.$x(cameraPreviewButton);
  await cameraPreviewButtonObj[0].click();

}



async function enterUsernameAndClickSubmit(page, username){
    try {
      await delay(1000)
      await expect(page).toMatchElement('h1', { text: 'Forgot Password?' });
    } catch (err) {
      const forgotPasswordLink = await page.$x(forgotPassword);
      await forgotPasswordLink[0].click();
      await page.waitForXPath("//h1[text()='Forgot Password?']", { timeout: config.timeout }, { visible: true });
    }
    
    await page.type(usernameField, username);
    await page.click(passwordResetSubmitButton);

}

async function clickBackToLogin(page){
    const backToLoginLink = await page.$x(backToLogin);
    await backToLoginLink[0].click();

}

async function enterOutlookUsername(page, username){
    await page.type(outlookEmailField, username);
    await page.click(outlookSubmitButton);
    await page.waitForNavigation();
}

async function enterOutlookPassword(page, password){
    await page.type(outlookPasswordField, password);
    await page.click(outlookSubmitButton);
    await page.waitForNavigation();
}

async function clickNoOnStaySignedInPage(page){
    await page.click(noButton);  
}

async function clickOnFirstResetPasswordMail(page){
    await page.waitForSelector(outlookHomePageMenuButton);
    const firstResetPasswordMail = await page.$x(resetPasswordMail);
    await firstResetPasswordMail[0].click();
    
}

async function clickResetPasswordLink(page){
    await page.waitForSelector(likeButton);
    await expect(page).toClick('a', { text: resetPasswordLink }, {
        timeout: config.timeout});

}

async function resetPassword(page, password, passwordConfirm){
    await page.bringToFront();
    await page.waitForSelector(passwordResetSubmitButton);
    await expect(page).toMatch(resetPasswordText);
    await page.type(newPasswordField, password);
    await page.type(confirmPasswordField, passwordConfirm);
    await page.click(passwordResetSubmitButton);

}

async function dismissPasswordResetConfirmationMessage(page){
    await page.click(OkButton);
    await page.close();
}

async function loginToIWS(page, username, password){
    await page.type(usernameField, username);
    const continueButtonObj = await page.$x(continueButton);
    await continueButtonObj[0].click();
    await page.waitFor(2000);
    await page.type(passwordField, password);
    await page.click(signInButton);
}

async function clickOnUsernameDropdown(page){
    const caretDownButton = await page.$x(userDropdown);
    await caretDownButton[0].click();
}

async function clickOnLogoutButton(page){
    const logoutButton = await page.$x(signoutButton);
    await logoutButton[0].click();
}

async function clickOnHistoryButton(page){
    const iwsHistoryButton = await page.$x(historyButton);
    await iwsHistoryButton[0].click();
}

async function clickOnDiagnosticButton(page){
    const iwsdiagnosticButton = await page.$x(diagnosticButton);
    await iwsdiagnosticButton[0].click();
}

async function clickOnVersionButton(page){
    await page.waitForXPath(versionButton, { timeout: config.timeout }, { visible: true });
    const iwsVersionButton = await page.$x(versionButton);
    await iwsVersionButton[0].click();
}

async function clickOnSpeedTestButton(page){
    await page.waitForXPath(speedTestButton, { timeout: config.timeout }, { visible: true });
    const iwsSpeedTestButton = await page.$x(speedTestButton);
    await iwsSpeedTestButton[0].click();
}

async function clickOnMicrophoneButton(page){
    await page.waitForXPath(microphoneButton, { timeout: config.timeout }, { visible: true });
    const iwsMicrophoneButton = await page.$x(microphoneButton);
    await iwsMicrophoneButton[0].click();
}

async function changeUserStatus(page, status){

    await delay(1000);
    await page.waitForSelector("//span[text()='Unavailable']", { timeout: config.timeout }, { visible: true });
    const availabilityMenuButton = await page.$x("//span[text()='Unavailable']");
    await availabilityMenuButton[0].click();
    await delay(2000);
    await page.waitForXPath("//span[text()='Unavailable']", { timeout: config.timeout }, { visible: true });
    const toSetStatus = await page.$x("//span[text()='Unavailable']");
    await toSetStatus[0].click();
    await expect(page).toMatchElement('span', {text: status}, { timeout: config.timeout }, { visible: true });

  }

  async function changeUserStatus2(page, status){

    await delay(1000);
    await page.waitForSelector('span[id="button--listbox-input--2"]', { timeout: config.timeout }, { visible: true });
    const availabilityMenuButton = await page.$x("//span[@id='button--listbox-input--2']/span");
    await availabilityMenuButton[0].click();
    await page.waitForXPath("//span[text()='Transfer']", { timeout: config.timeout }, { visible: true });
    const toSetStatus = await page.$x("//span[text()='Transfer']");
    await toSetStatus[0].click();
    await expect(page).toMatchElement('span', {text: status}, { timeout: config.timeout }, { visible: true });

  }


async function iwsSignout(page){

    await page.waitForSelector('button[data-e2e="user-menu-button"]', { timeout: config.timeout }, { visible: true });
    await clickOnUsernameDropdown(page);
    await clickOnLogoutButton(page);
    await page.waitForXPath("//h1[text()='Logged Out']", {timeout: config.timeout}, { visible: true });
    await expect(page).toMatch("You've been successfully logged out.", {
      timeout: config.timeout
    });
    
  }

//callType : Queue, Requeue, Add, Transfer
async function iwsAcceptCall(page, callType){

    if (callType == "Transfer") {
        const acceptButton = await page.$x("/html/body/div[2]/div/div[3]/div/div[3]/div/button[2]");
        await acceptButton[0].click();
      } 
      else {
        const acceptButton = await page.$x("//button[@data-e2e='incoming-direct-dialog-accept']");
        await acceptButton[0].click();
      }
      
      await expect(page).toMatchElement('#session--remote-video-container', {
        timeout: config.timeout
      });
  }

//callType : Queue, Requeue, Add, Transfer
async function iwsDeclineCall(page, callType){

    if (callType == "Transfer") {
        await page.waitForSelector('span[icon="swap-horizontal"]', { visible: true });
        const declineButton = await page.$x("//button[@data-e2e='incoming-transfer-dialog-decline']");
        await declineButton[0].click();
      } else {
        await page.waitForSelector('span[icon="phone"]', { visible: true });
        const declineButton = await page.$x("//button[@data-e2e='incoming-call-dialog-decline']");
        await declineButton[0].click();
      }

        await page.waitForXPath("//h5[text()='AVAILABILITY']", { timeout: config.timeout }, { visible: true });
  }

//callType : Queue, Requeue, Add, Transfer
async function iwsDeclineCallXButton(page, callType){

    if (callType == "Transfer") {
        await page.waitForSelector('span[icon="swap-horizontal"]', { visible: true });
      } else {
        await page.waitForSelector('span[icon="phone"]', { visible: true });
      }

        const declineXButton = await page.$x("//span[@icon='small-cross']");
        await declineXButton[0].click();

        await page.waitForXPath("//h5[text()='AVAILABILITY']", { timeout: config.timeout }, { visible: true });
  }

  async function iwsEndCall(page){

    await page.waitForXPath("//button[@type='button'][@title='End']", { timeout: config.timeout }, { visible: true });
    const endVideoButton = await page.$x("//button[@type='button'][@title='End']");
    await endVideoButton[0].click();
    await page.waitForSelector('button[data-e2e="confirm-dialog-accept"]', { visible: true });
    const confirmButton = await page.$x("//button[@type='button']//span[text()='Confirm']");
    await confirmButton[0].click();
  
    await delay(3000);

  }

async function pressEscapeOnCallNotification(page){
  await page.keyboard.press('Escape');
  await page.waitFor(500);

}

async function getToolTipVerbiageStartEnd(page){
  await page.waitForXPath("//abbr[text()='Start']", { timeout: config.timeout }, { visible: true });

  const startElement = await page.$x("//abbr[text()='Start']");
  var getTextJSon = await startElement[0].getProperty('title');
  var startToolTip = await getTextJSon.jsonValue();

  const endElement = await page.$x("//abbr[text()='End']");
  var getTextJSon = await endElement[0].getProperty('title');
  var endToolTip = await getTextJSon.jsonValue();

  return {
    startToolTip,
    endToolTip
  };

}

async function doPSTNCall(page, pstnNo){

  await page.waitForSelector('input[type="tel"]', { timeout: config.timeout }, { visible: true });
  await page.type('input[type="tel"]', pstnNo);
  await page.waitFor(1000);
  await page.waitForXPath("//span[text()='Call']", {timeout: config.timeout}, { visible: true });
  const callButtonElement = await page.$x("//span[text()='Call']");
  await callButtonElement[0].click();
  await page.waitFor(2000);
  await expect(page).toMatchElement('p', { text: 'Please check the Participants List.' }, { timeout: config.timeout }, { visible: true });
  
}

async function hangupLastPSTNCall(page, pstnNo){

  await page.waitForXPath("//span[text()='"+pstnNo+"']//following::button[@data-e2e='user-menu-button']", {timeout: config.timeout}, { visible: true });
  const pstnMoreButtonElement = await page.$x("//span[text()='"+pstnNo+"']//following::button[@data-e2e='user-menu-button']");
  await pstnMoreButtonElement[0].click();
  const hangupButtonElement = await page.$x("//div[@data-valuetext='Hangup']");
  await hangupButtonElement[hangupButtonElement.length-1].click();
  
}

async function clickOnCollapseButton(page){

  await page.waitForSelector(collapseButton, { timeout: config.timeout }, { visible: true });
  await page.click(collapseButton);
}

async function clickOnExpandButton(page){

  await page.waitForSelector(expandButton, { timeout: config.timeout }, { visible: true });
  await page.click(expandButton);
}


module.exports = { 
    clickOnForgotPassword,
    enterUsernameAndClickSubmit,
    clickBackToLogin,
    enterOutlookUsername,
    enterOutlookPassword,
    clickNoOnStaySignedInPage,
    clickOnFirstResetPasswordMail,
    clickResetPasswordLink,
    resetPassword,
    dismissPasswordResetConfirmationMessage,
    loginToIWS,
    clickOnUsernameDropdown,
    clickOnLogoutButton,
    clickOnHistoryButton,
    clickOnDiagnosticButton,
    clickOnVersionButton,
    clickOnSpeedTestButton,
    clickOnMicrophoneButton,
    changeUserStatus,
    changeUserStatus2,
    iwsSignout,
    iwsAcceptCall,
    iwsDeclineCall,
    iwsDeclineCallXButton,
    iwsEndCall,
    pressEscapeOnCallNotification,
    getToolTipVerbiageStartEnd,
    doPSTNCall,
    hangupLastPSTNCall,
    clickOnCameraPreview,
    clickOnCollapseButton,
    clickOnExpandButton,
    cameraPreviewButton,
    callViewLeftSide,
    callViewRightSide,
 }