var config = require('../config');

const delay = milliseconds => {
    return new Promise(resolve => setTimeout(resolve, milliseconds));
  };


const forgotPassword = "//a[contains(@href,'forgot-password')]";
const usernameField = 'input[name="username"]';
const passwordField = 'input[name="password"]';
const passwordResetSubmitButton = 'button[type="submit"]';
const signInButton = 'button';
const amnLogo = 'img[alt="AMN Healthcare Logo"]';
const userDropdown = "//button[@data-e2e='user-menu-button']";
const statusDropdown = "//span[@id='button--listbox-input--2']/span";
const seesionEndButton = 'button[data-e2e="session-end-button"]';


async function clickOnForgotPassword(page){
    const forgotPasswordLink = await page.$x(forgotPassword);
    await forgotPasswordLink[0].click();

}

async function enterUsernameAndClickSubmitForgotPassword(page, username){
  try {
    await delay(1000)
    await expect(page).toMatchElement('h1', { text: 'Forgot Password?' });
  } catch (err) {
    const forgotPasswordLink = await page.$x(forgotPassword);
    await forgotPasswordLink[0].click();
    await page.waitForXPath("//h1[text()='Forgot Password?']", { timeout: config.timeout }, { visible: true });
  }
  
  await page.type(usernameField, username);
  await page.click(passwordResetSubmitButton);
}

async function clickBackToLogin(page){
  const backToLoginLink = await page.$x("//a[contains(@href,'login')]");
  await backToLoginLink[0].click();
}

async function loginToCWS(page, username, password){
  
  await expect(page).toMatch('Forgot');
  await page.type(usernameField, username);
  await page.type(passwordField, password);
  await page.click(signInButton);
}

async function clickOnUsernameDropdown(page){
  const caretDownButton = await page.$x(userDropdown);
  await caretDownButton[0].click();
}

async function clickStatusDropdown(page){
  await page.waitForXPath(statusDropdown, { timeout: config.timeout }, { visible: true });
  const statusDropdownEle = await page.$x(statusDropdown);
  await statusDropdownEle[0].click();
}

async function changeUserStatus(page, status){

  await clickStatusDropdown(page);
  await page.waitForXPath("//span[text()='"+status+"']", { timeout: config.timeout }, { visible: true });
  const toSetStatus = await page.$x("//span[text()='"+status+"']");
  await toSetStatus[0].click();
  await expect(page).toMatchElement('span', {text: status}, { timeout: config.timeout }, { visible: true });

}

async function cwsAcceptCall(page){

  await page.waitForSelector('span[icon="phone"]', { timeout: config.timeout }, { visible: true });
  const acceptButton = await page.$x("//button[@data-e2e='incoming-call-dialog-accept']");
  await acceptButton[0].click();
}

module.exports = {
  clickOnForgotPassword,
  enterUsernameAndClickSubmitForgotPassword,
  clickBackToLogin,
  loginToCWS,
  clickOnUsernameDropdown,
  clickStatusDropdown,
  changeUserStatus,
  cwsAcceptCall,
  amnLogo,
  seesionEndButton,
 }