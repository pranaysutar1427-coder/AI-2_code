var config = require('../config');
var helperFuncs = require('../utils/helperFunctions');

const delay = milliseconds => {
    return new Promise(resolve => setTimeout(resolve, milliseconds));
  };

const usernameField = 'input[name="username"]';
const passwordField = 'input[name=password]';
const submitButton = 'button[type="button"]';
const availabiltyArea = 'div[class="Home__availability___34D-4"]';
const closeNotificationButton = 'button[aria-label="close"]';

async function loginToContrator(page, username, password){
  await page.waitForSelector(usernameField, { timeout: config.timeout }, { visible: true });
  await page.type(usernameField, username);
  await page.type(passwordField, password);
  await page.click(submitButton);
  await page.waitForSelector(availabiltyArea, { timeout: config.timeout }, { visible: true });

}

async function closeNotification(page, username, password){
  await page.waitForSelector(closeNotificationButton, { timeout: config.timeout }, { visible: true });
  await page.click(closeNotificationButton);

}


module.exports = {
  loginToContrator,
  closeNotification,
  
 }